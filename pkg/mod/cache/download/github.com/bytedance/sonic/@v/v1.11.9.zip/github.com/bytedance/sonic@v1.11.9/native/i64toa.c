#include "fastint.h"


int i64toa(char *out, int64_t val) {
    return i64toa_1(out, val);
}